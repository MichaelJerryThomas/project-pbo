package ketikstr;

import java.util.Scanner;

public class KetikStr {
    public static String ketik(){
        Scanner input = new Scanner(System.in);
        return input.nextLine();
    }
}



