package Modul_10;
interface Email {/*Deklarasi sebuah antarmuka Java bernama "Email". Antarmuka digunakan untuk 
mendefinisikan kontrak metode-metode yang harus diimplementasikan oleh kelas-kelas yang menggunakannya.*/

    String getEmail();/*Deklarasi metode "getEmail()" yang harus diimplementasikan oleh kelas-kelas yang 
    mengimplementasikan antarmuka "Email". Metode ini mengembalikan nilai bertipe String yang merupakan alamat email.*/
}



