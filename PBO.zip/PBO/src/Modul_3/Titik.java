package Modul_3;
public class Titik {
    // mendeklarasikan atribut
    private int x, y;
    //deklarasi constructor dengan parameter x dan y
    public Titik (int x, int y){ //constructor Titik
        this.x = x;
        this.y = y; }
    //deklarasikan setter setX dengan parameter x
    public void setX (int x) {
        this.x= x; }
    //deklarasikan setter setY dengan parameter y
    public void setY(int y) {
        this.y= y; }
    //deklarasikan getter getX dengan parameter x
    public int getX () {
        return x;}
    //deklarasikan getter getY dengan parameter y
    public int getY () {
    return y;
    } 
}




