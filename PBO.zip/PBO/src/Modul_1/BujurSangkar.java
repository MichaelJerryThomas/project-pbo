/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Modul_1;

/**
 *
 * @author HP
 */
public class BujurSangkar {
    int sisi;// memesan variabel dengan nama sisi dengan tipe int
    double luas;// memesan variabel dengan nama luas dengan tipe double
    
    BujurSangkar() {};//membuat konstruktor lingkaran
    public double luas () //membuat method luas 
    {
        luas=sisi*sisi;//memnghitung luas
        return luas;//mengembalikan nilai luas
    }
}

