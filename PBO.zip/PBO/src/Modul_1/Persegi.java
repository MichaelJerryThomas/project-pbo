/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modul_1;

/**
 *
 * @author HP
 */
public class Persegi {
int panj; // memesan variabel dengan nama panj dengan tipe int
int lebar; // memesan variabel dengan nama lebar dengan tipe int
double luas; // memesan variabel dengan nama luas dengan tipe double
 
Persegi(){}; // membuat konstruktor
public double luas() // membuat method luas 
{
luas=panj*lebar; // memnghitung luas 
 return luas; // mengembalikan nilai luas
}
 }


