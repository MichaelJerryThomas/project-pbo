/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Modul_1;

/**
 *
 * @author HP
 */
public class LingkaranMain {
    public static void main(String[] args) {
        Lingkaran lingkar1=new Lingkaran (); // Membuat objek dengan nama "lingkar1"
        lingkar1.luas();//objek lingkar1 memanggil method luas
    }
}


